let config = {

    quest_lady_in_distress_reward_exp: 100,
 
};
/* Constanten Nutzen wenn es nicht geaendert werden soll 
 * und diese am besten gross schreiben damit man sie besser erkennt
 */

let result = false;

/*
do {
    let heroName = prompt('Name your Hero?', "WinchesterOP");
    let question = `Your Hero will be named: ${heroName}. Are you Sure?`;

    result = confirm(question);

    if (result) {
        hero.setHeroName(heroName)
        logging("INFO", "Hero name was setted as: \"" + hero.name + "\"");
    }
} while (!result);

*/

hero.firstInitialization();
background_timer.startCounting();